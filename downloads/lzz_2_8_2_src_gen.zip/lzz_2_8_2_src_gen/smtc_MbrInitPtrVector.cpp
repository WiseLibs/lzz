// smtc_MbrInitPtrVector.cpp
//

#include "smtc_MbrInitPtrVector.h"
#define LZZ_INLINE inline
#undef LZZ_INLINE
