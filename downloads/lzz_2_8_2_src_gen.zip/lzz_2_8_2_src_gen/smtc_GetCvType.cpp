// smtc_GetCvType.cpp
//

#include "smtc_GetCvType.h"
#ifndef LZZ_ENABLE_INLINE
#include "smtc_GetCvType.inl"
#endif
#define LZZ_INLINE inline
#undef LZZ_INLINE
