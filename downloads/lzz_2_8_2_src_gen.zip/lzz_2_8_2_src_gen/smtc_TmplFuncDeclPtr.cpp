// smtc_TmplFuncDeclPtr.cpp
//

#include "smtc_TmplFuncDeclPtr.h"
#include "smtc_TmplFuncDecl.h"
#include "util_BPtr.tpl"
#define LZZ_INLINE inline
template class util::BPtr <smtc::TmplFuncDecl>;
#undef LZZ_INLINE
