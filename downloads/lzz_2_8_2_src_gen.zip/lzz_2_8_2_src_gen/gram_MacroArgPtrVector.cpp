// gram_MacroArgPtrVector.cpp
//

#include "gram_MacroArgPtrVector.h"
#define LZZ_INLINE inline
#undef LZZ_INLINE
