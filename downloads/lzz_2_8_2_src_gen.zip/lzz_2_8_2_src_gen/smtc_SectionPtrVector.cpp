// smtc_SectionPtrVector.cpp
//

#include "smtc_SectionPtrVector.h"
#define LZZ_INLINE inline
#undef LZZ_INLINE
