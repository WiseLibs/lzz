// smtc_Access.cpp
//

#include "smtc_Access.h"
#define LZZ_INLINE inline
#undef LZZ_INLINE
