// util_CharKeyTable.h
//

#ifndef LZZ_util_CharKeyTable_h
#define LZZ_util_CharKeyTable_h
// util
#include "util_KeyTable.h"
#define LZZ_INLINE inline
namespace util
{
  typedef KeyTable <char> CharKeyTable;
}
#undef LZZ_INLINE
#endif
