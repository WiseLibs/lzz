// smtc_IsNsEnclUnmd.h
//

#ifndef LZZ_smtc_IsNsEnclUnmd_h
#define LZZ_smtc_IsNsEnclUnmd_h
// semantic
#include "smtc_NsPtr.h"
#define LZZ_INLINE inline
namespace smtc
{
  bool isNsEnclUnmd (NsPtr const & ns);
}
#undef LZZ_INLINE
#endif
