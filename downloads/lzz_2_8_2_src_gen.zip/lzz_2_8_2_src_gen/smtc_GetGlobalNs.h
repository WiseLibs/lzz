// smtc_GetGlobalNs.h
//

#ifndef LZZ_smtc_GetGlobalNs_h
#define LZZ_smtc_GetGlobalNs_h
// semantic
#include "smtc_NsPtr.h"
#define LZZ_INLINE inline
namespace smtc
{
  NsPtr getGlobalNs ();
}
#undef LZZ_INLINE
#endif
