// basl_LRData.cpp
//

#include "basl_LRData.h"
#define LZZ_INLINE inline
#undef LZZ_INLINE
