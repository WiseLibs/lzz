// smtc_Linkage.cpp
//

#include "smtc_Linkage.h"
#ifndef LZZ_ENABLE_INLINE
#include "smtc_Linkage.inl"
#endif
// semantic
#define LZZ_INLINE inline
namespace smtc
{
  Linkage::Linkage ()
    {}
}
#undef LZZ_INLINE
