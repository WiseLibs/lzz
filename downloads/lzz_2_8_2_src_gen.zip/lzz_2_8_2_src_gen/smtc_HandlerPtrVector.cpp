// smtc_HandlerPtrVector.cpp
//

#include "smtc_HandlerPtrVector.h"
#define LZZ_INLINE inline
#undef LZZ_INLINE
