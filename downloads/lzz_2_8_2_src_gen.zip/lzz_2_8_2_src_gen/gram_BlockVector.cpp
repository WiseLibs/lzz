// gram_BlockVector.cpp
//

#include "gram_BlockVector.h"
#define LZZ_INLINE inline
#undef LZZ_INLINE
