// smtc_PrintParamAsObj.cpp
//

#include "smtc_PrintParamAsObj.h"
// semantic
#include "smtc_GetNameLoc.h"
#include "smtc_Param.h"
#include "smtc_PrintCode.h"
#define LZZ_INLINE inline
namespace smtc
{
  using namespace util;
}
#undef LZZ_INLINE
