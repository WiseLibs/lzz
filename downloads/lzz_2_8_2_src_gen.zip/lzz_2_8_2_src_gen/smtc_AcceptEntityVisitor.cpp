// smtc_AcceptEntityVisitor.cpp
//

#include "smtc_AcceptEntityVisitor.h"
#ifndef LZZ_ENABLE_INLINE
#include "smtc_AcceptEntityVisitor.inl"
#endif
#define LZZ_INLINE inline
namespace smtc
{
  AcceptEntityVisitor::~ AcceptEntityVisitor ()
              {}
}
#undef LZZ_INLINE
