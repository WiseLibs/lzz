// smtc_Entity.cpp
//

#include "smtc_Entity.h"
#ifndef LZZ_ENABLE_INLINE
#include "smtc_Entity.inl"
#endif
#define LZZ_INLINE inline
#undef LZZ_INLINE
