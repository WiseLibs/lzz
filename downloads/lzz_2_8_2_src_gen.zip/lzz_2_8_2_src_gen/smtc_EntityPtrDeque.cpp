// smtc_EntityPtrDeque.cpp
//

#include "smtc_EntityPtrDeque.h"
#define LZZ_INLINE inline
#undef LZZ_INLINE
