// smtc_EnumtorPtr.cpp
//

#include "smtc_EnumtorPtr.h"
#include "smtc_Enumtor.h"
#include "util_BPtr.tpl"
#define LZZ_INLINE inline
template class util::BPtr <smtc::Enumtor>;
#undef LZZ_INLINE
