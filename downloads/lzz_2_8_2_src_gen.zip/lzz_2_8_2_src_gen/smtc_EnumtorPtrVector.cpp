// smtc_EnumtorPtrVector.cpp
//

#include "smtc_EnumtorPtrVector.h"
#define LZZ_INLINE inline
#undef LZZ_INLINE
