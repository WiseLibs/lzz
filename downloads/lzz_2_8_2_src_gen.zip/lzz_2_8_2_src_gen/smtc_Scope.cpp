// smtc_Scope.cpp
//

#include "smtc_Scope.h"
#define LZZ_INLINE inline
namespace smtc
{
  Scope::Scope ()
    {}
}
namespace smtc
{
  Scope::~ Scope ()
    {}
}
#undef LZZ_INLINE
