// util_StringDeque.cpp
//

#include "util_StringDeque.h"
#define LZZ_INLINE inline
#undef LZZ_INLINE
