// basl_RecCmdPtrDeque.cpp
//

#include "basl_RecCmdPtrDeque.h"
#define LZZ_INLINE inline
#undef LZZ_INLINE
