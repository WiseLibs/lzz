// smtc_Access.h
//

#ifndef LZZ_smtc_Access_h
#define LZZ_smtc_Access_h
#define LZZ_INLINE inline
namespace smtc
{
  enum Access
  {
    DEFAULT_ACCESS,
    PUBLIC_ACCESS,
    PRIVATE_ACCESS,
    PROTECTED_ACCESS
  };
}
#undef LZZ_INLINE
#endif
