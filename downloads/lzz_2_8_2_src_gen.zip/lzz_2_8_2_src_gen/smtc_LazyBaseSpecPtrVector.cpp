// smtc_LazyBaseSpecPtrVector.cpp
//

#include "smtc_LazyBaseSpecPtrVector.h"
#define LZZ_INLINE inline
#undef LZZ_INLINE
