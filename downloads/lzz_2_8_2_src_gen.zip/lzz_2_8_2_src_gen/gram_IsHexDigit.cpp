// gram_IsHexDigit.cpp
//

#include "gram_IsHexDigit.h"
#ifndef LZZ_ENABLE_INLINE
#include "gram_IsHexDigit.inl"
#endif
#define LZZ_INLINE inline
#undef LZZ_INLINE
