// util_IdentList.cpp
//

#include "util_IdentList.h"
#define LZZ_INLINE inline
#undef LZZ_INLINE
