// gram_Nonterm.cpp
//

#include "gram_Nonterm.h"
#ifndef LZZ_ENABLE_INLINE
#include "gram_Nonterm.inl"
#endif
#include "basl_NontermInfo.h"
#include "gram_Visitor.h"
#define LZZ_INLINE inline
namespace
{
  void accept_0 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_1 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_2 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_3 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_4 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_5 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_6 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_7 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_8 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_9 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_10 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_11 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_12 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_13 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_14 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_15 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_16 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_17 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_18 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_19 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_20 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_21 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_22 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_23 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_24 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_25 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_26 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_27 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_28 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_29 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_30 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_31 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_32 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_33 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_34 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_35 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_36 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_37 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_38 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_39 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_40 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_41 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_42 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_43 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_44 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_45 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_46 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_47 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_48 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_49 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_50 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_51 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_52 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_53 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_54 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_55 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_56 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_57 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_58 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_59 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_60 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_61 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_62 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_63 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_64 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_65 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_66 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_67 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_68 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_69 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_70 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_71 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_72 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_73 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_74 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_75 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_76 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_77 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_78 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_79 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_80 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_81 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_82 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_83 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_84 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_85 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_86 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_87 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_88 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_89 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_90 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_91 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_92 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_93 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_94 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_95 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_96 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_97 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_98 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_99 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_100 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_101 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_102 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_103 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_104 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_105 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_106 (basl::Nonterm & nonterm, basl::Visitor const & visitor);
}
namespace
{
  void accept_0 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::SimpleDeclNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_1 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::NestedSimpleDecl1Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_2 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::NestedSimpleDecl2Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_3 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::NestedSimpleDecl3Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_4 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::NestedDeclNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_5 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::ObjInit1Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_6 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::ObjInit2Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_7 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::ObjInit3Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_8 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::BlockNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_9 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::NestedName1Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_10 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::NestedName2Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_11 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::Name1Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_12 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::Name2Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_13 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::Name3Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_14 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::BaseName1Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_15 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::Name4Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_16 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::Name5Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_17 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::BaseName2Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_18 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::BaseName3Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_19 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::BaseName4Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_20 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::Oper1Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_21 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::Oper2Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_22 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::Oper3Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_23 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::Oper4Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_24 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::Oper5Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_25 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::DeclSpecNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_26 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::CVSpecNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_27 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::SeqNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_28 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::FtorSpecNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_29 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::UserTypeNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_30 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::ElabTypeNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_31 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::BuiltInTypeNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_32 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::DclNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_33 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::DirectDcl1Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_34 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::DirectDcl2Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_35 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::DirectDcl3Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_36 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::PureDclNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_37 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::PureNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_38 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::DirectDcl4Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_39 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::PtrOper1Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_40 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::PtrOper2Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_41 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::PtrOper3Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_42 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::IdNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_43 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::ParamDeclBody1Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_44 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::ParamDeclBody2Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_45 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::ParamDeclBody3Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_46 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::ParamDeclBody4Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_47 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::ParamDecl1Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_48 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::ParamDecl2Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_49 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::Decl2Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_50 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::Decl1Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_51 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::TypeIdNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_52 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::NamespaceDefNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_53 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::NamespaceHead1Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_54 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::NamespaceHead2Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_55 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::ClassDefNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_56 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::ClassHeadNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_57 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::BaseSpec1Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_58 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::BaseSpec2Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_59 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::BaseSpec3Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_60 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::AccessSpecNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_61 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::ClassDeclNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_62 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::FriendClassDeclNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_63 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::FuncDefNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_64 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::MbrInitNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_65 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::HandlerNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_66 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::TmplDeclNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_67 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::TmplSpecNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_68 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::TypeParam1Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_69 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::TypeParam2Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_70 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::TmplTmplParam1Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_71 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::TmplTmplParam2Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_72 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::TmplInstNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_73 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::TmplInstBeginNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_74 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::LazyCtorNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_75 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::LazyCtorBegin1Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_76 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::LazyCtorBegin2Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_77 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::LazyBaseSpec1Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_78 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::LazyBaseSpec2Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_79 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::LazyBaseSpec3Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_80 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::DirectDcl5Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_81 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::FunctorDefNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_82 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::FunctorDeclTypeNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_83 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::EnumDefNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_84 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::EnumtorDecl1Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_85 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::EnumtorDecl2Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_86 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::UsingDeclNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_87 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::UsingDirNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_88 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::LinkageSpecNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_89 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::LinkageBlockBeginNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_90 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::LinkageDeclBeginNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_91 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::NavDefNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_92 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::NavHeadNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_93 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::NavDirectDcl1Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_94 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::NavVisitFuncDefNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_95 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::ReturnStmtNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_96 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::VdfDefNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_97 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::VdfHeadNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_98 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::VdfFunctorDefNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_99 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::VdfShortData1DefNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_100 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::VdfShortData2DefNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_101 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::VdfDataParamListNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_102 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::ObjInit4Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_103 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::VdfBlockDataDefNode node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_104 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::VdfBlockDataHead1Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_105 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::VdfBlockDataHead2Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace
{
  void accept_106 (basl::Nonterm & nonterm, basl::Visitor const & visitor)
  {
    gram::DirectDcl6Node node (nonterm);
    static_cast <gram::Visitor const &> (visitor).visit (node);
  }
}
namespace gram
{
  basl::NontermInfo const SimpleDeclNode::info = { "SimpleDeclNode", accept_0 };
}
namespace gram
{
  basl::NontermInfo const NestedSimpleDecl1Node::info = { "NestedSimpleDecl1Node", accept_1 };
}
namespace gram
{
  basl::NontermInfo const NestedSimpleDecl2Node::info = { "NestedSimpleDecl2Node", accept_2 };
}
namespace gram
{
  basl::NontermInfo const NestedSimpleDecl3Node::info = { "NestedSimpleDecl3Node", accept_3 };
}
namespace gram
{
  basl::NontermInfo const NestedDeclNode::info = { "NestedDeclNode", accept_4 };
}
namespace gram
{
  basl::NontermInfo const ObjInit1Node::info = { "ObjInit1Node", accept_5 };
}
namespace gram
{
  basl::NontermInfo const ObjInit2Node::info = { "ObjInit2Node", accept_6 };
}
namespace gram
{
  basl::NontermInfo const ObjInit3Node::info = { "ObjInit3Node", accept_7 };
}
namespace gram
{
  basl::NontermInfo const BlockNode::info = { "BlockNode", accept_8 };
}
namespace gram
{
  basl::NontermInfo const NestedName1Node::info = { "NestedName1Node", accept_9 };
}
namespace gram
{
  basl::NontermInfo const NestedName2Node::info = { "NestedName2Node", accept_10 };
}
namespace gram
{
  basl::NontermInfo const Name1Node::info = { "Name1Node", accept_11 };
}
namespace gram
{
  basl::NontermInfo const Name2Node::info = { "Name2Node", accept_12 };
}
namespace gram
{
  basl::NontermInfo const Name3Node::info = { "Name3Node", accept_13 };
}
namespace gram
{
  basl::NontermInfo const BaseName1Node::info = { "BaseName1Node", accept_14 };
}
namespace gram
{
  basl::NontermInfo const Name4Node::info = { "Name4Node", accept_15 };
}
namespace gram
{
  basl::NontermInfo const Name5Node::info = { "Name5Node", accept_16 };
}
namespace gram
{
  basl::NontermInfo const BaseName2Node::info = { "BaseName2Node", accept_17 };
}
namespace gram
{
  basl::NontermInfo const BaseName3Node::info = { "BaseName3Node", accept_18 };
}
namespace gram
{
  basl::NontermInfo const BaseName4Node::info = { "BaseName4Node", accept_19 };
}
namespace gram
{
  basl::NontermInfo const Oper1Node::info = { "Oper1Node", accept_20 };
}
namespace gram
{
  basl::NontermInfo const Oper2Node::info = { "Oper2Node", accept_21 };
}
namespace gram
{
  basl::NontermInfo const Oper3Node::info = { "Oper3Node", accept_22 };
}
namespace gram
{
  basl::NontermInfo const Oper4Node::info = { "Oper4Node", accept_23 };
}
namespace gram
{
  basl::NontermInfo const Oper5Node::info = { "Oper5Node", accept_24 };
}
namespace gram
{
  basl::NontermInfo const DeclSpecNode::info = { "DeclSpecNode", accept_25 };
}
namespace gram
{
  basl::NontermInfo const CVSpecNode::info = { "CVSpecNode", accept_26 };
}
namespace gram
{
  basl::NontermInfo const SeqNode::info = { "SeqNode", accept_27 };
}
namespace gram
{
  basl::NontermInfo const FtorSpecNode::info = { "FtorSpecNode", accept_28 };
}
namespace gram
{
  basl::NontermInfo const UserTypeNode::info = { "UserTypeNode", accept_29 };
}
namespace gram
{
  basl::NontermInfo const ElabTypeNode::info = { "ElabTypeNode", accept_30 };
}
namespace gram
{
  basl::NontermInfo const BuiltInTypeNode::info = { "BuiltInTypeNode", accept_31 };
}
namespace gram
{
  basl::NontermInfo const DclNode::info = { "DclNode", accept_32 };
}
namespace gram
{
  basl::NontermInfo const DirectDcl1Node::info = { "DirectDcl1Node", accept_33 };
}
namespace gram
{
  basl::NontermInfo const DirectDcl2Node::info = { "DirectDcl2Node", accept_34 };
}
namespace gram
{
  basl::NontermInfo const DirectDcl3Node::info = { "DirectDcl3Node", accept_35 };
}
namespace gram
{
  basl::NontermInfo const PureDclNode::info = { "PureDclNode", accept_36 };
}
namespace gram
{
  basl::NontermInfo const PureNode::info = { "PureNode", accept_37 };
}
namespace gram
{
  basl::NontermInfo const DirectDcl4Node::info = { "DirectDcl4Node", accept_38 };
}
namespace gram
{
  basl::NontermInfo const PtrOper1Node::info = { "PtrOper1Node", accept_39 };
}
namespace gram
{
  basl::NontermInfo const PtrOper2Node::info = { "PtrOper2Node", accept_40 };
}
namespace gram
{
  basl::NontermInfo const PtrOper3Node::info = { "PtrOper3Node", accept_41 };
}
namespace gram
{
  basl::NontermInfo const IdNode::info = { "IdNode", accept_42 };
}
namespace gram
{
  basl::NontermInfo const ParamDeclBody1Node::info = { "ParamDeclBody1Node", accept_43 };
}
namespace gram
{
  basl::NontermInfo const ParamDeclBody2Node::info = { "ParamDeclBody2Node", accept_44 };
}
namespace gram
{
  basl::NontermInfo const ParamDeclBody3Node::info = { "ParamDeclBody3Node", accept_45 };
}
namespace gram
{
  basl::NontermInfo const ParamDeclBody4Node::info = { "ParamDeclBody4Node", accept_46 };
}
namespace gram
{
  basl::NontermInfo const ParamDecl1Node::info = { "ParamDecl1Node", accept_47 };
}
namespace gram
{
  basl::NontermInfo const ParamDecl2Node::info = { "ParamDecl2Node", accept_48 };
}
namespace gram
{
  basl::NontermInfo const Decl2Node::info = { "Decl2Node", accept_49 };
}
namespace gram
{
  basl::NontermInfo const Decl1Node::info = { "Decl1Node", accept_50 };
}
namespace gram
{
  basl::NontermInfo const TypeIdNode::info = { "TypeIdNode", accept_51 };
}
namespace gram
{
  basl::NontermInfo const NamespaceDefNode::info = { "NamespaceDefNode", accept_52 };
}
namespace gram
{
  basl::NontermInfo const NamespaceHead1Node::info = { "NamespaceHead1Node", accept_53 };
}
namespace gram
{
  basl::NontermInfo const NamespaceHead2Node::info = { "NamespaceHead2Node", accept_54 };
}
namespace gram
{
  basl::NontermInfo const ClassDefNode::info = { "ClassDefNode", accept_55 };
}
namespace gram
{
  basl::NontermInfo const ClassHeadNode::info = { "ClassHeadNode", accept_56 };
}
namespace gram
{
  basl::NontermInfo const BaseSpec1Node::info = { "BaseSpec1Node", accept_57 };
}
namespace gram
{
  basl::NontermInfo const BaseSpec2Node::info = { "BaseSpec2Node", accept_58 };
}
namespace gram
{
  basl::NontermInfo const BaseSpec3Node::info = { "BaseSpec3Node", accept_59 };
}
namespace gram
{
  basl::NontermInfo const AccessSpecNode::info = { "AccessSpecNode", accept_60 };
}
namespace gram
{
  basl::NontermInfo const ClassDeclNode::info = { "ClassDeclNode", accept_61 };
}
namespace gram
{
  basl::NontermInfo const FriendClassDeclNode::info = { "FriendClassDeclNode", accept_62 };
}
namespace gram
{
  basl::NontermInfo const FuncDefNode::info = { "FuncDefNode", accept_63 };
}
namespace gram
{
  basl::NontermInfo const MbrInitNode::info = { "MbrInitNode", accept_64 };
}
namespace gram
{
  basl::NontermInfo const HandlerNode::info = { "HandlerNode", accept_65 };
}
namespace gram
{
  basl::NontermInfo const TmplDeclNode::info = { "TmplDeclNode", accept_66 };
}
namespace gram
{
  basl::NontermInfo const TmplSpecNode::info = { "TmplSpecNode", accept_67 };
}
namespace gram
{
  basl::NontermInfo const TypeParam1Node::info = { "TypeParam1Node", accept_68 };
}
namespace gram
{
  basl::NontermInfo const TypeParam2Node::info = { "TypeParam2Node", accept_69 };
}
namespace gram
{
  basl::NontermInfo const TmplTmplParam1Node::info = { "TmplTmplParam1Node", accept_70 };
}
namespace gram
{
  basl::NontermInfo const TmplTmplParam2Node::info = { "TmplTmplParam2Node", accept_71 };
}
namespace gram
{
  basl::NontermInfo const TmplInstNode::info = { "TmplInstNode", accept_72 };
}
namespace gram
{
  basl::NontermInfo const TmplInstBeginNode::info = { "TmplInstBeginNode", accept_73 };
}
namespace gram
{
  basl::NontermInfo const LazyCtorNode::info = { "LazyCtorNode", accept_74 };
}
namespace gram
{
  basl::NontermInfo const LazyCtorBegin1Node::info = { "LazyCtorBegin1Node", accept_75 };
}
namespace gram
{
  basl::NontermInfo const LazyCtorBegin2Node::info = { "LazyCtorBegin2Node", accept_76 };
}
namespace gram
{
  basl::NontermInfo const LazyBaseSpec1Node::info = { "LazyBaseSpec1Node", accept_77 };
}
namespace gram
{
  basl::NontermInfo const LazyBaseSpec2Node::info = { "LazyBaseSpec2Node", accept_78 };
}
namespace gram
{
  basl::NontermInfo const LazyBaseSpec3Node::info = { "LazyBaseSpec3Node", accept_79 };
}
namespace gram
{
  basl::NontermInfo const DirectDcl5Node::info = { "DirectDcl5Node", accept_80 };
}
namespace gram
{
  basl::NontermInfo const FunctorDefNode::info = { "FunctorDefNode", accept_81 };
}
namespace gram
{
  basl::NontermInfo const FunctorDeclTypeNode::info = { "FunctorDeclTypeNode", accept_82 };
}
namespace gram
{
  basl::NontermInfo const EnumDefNode::info = { "EnumDefNode", accept_83 };
}
namespace gram
{
  basl::NontermInfo const EnumtorDecl1Node::info = { "EnumtorDecl1Node", accept_84 };
}
namespace gram
{
  basl::NontermInfo const EnumtorDecl2Node::info = { "EnumtorDecl2Node", accept_85 };
}
namespace gram
{
  basl::NontermInfo const UsingDeclNode::info = { "UsingDeclNode", accept_86 };
}
namespace gram
{
  basl::NontermInfo const UsingDirNode::info = { "UsingDirNode", accept_87 };
}
namespace gram
{
  basl::NontermInfo const LinkageSpecNode::info = { "LinkageSpecNode", accept_88 };
}
namespace gram
{
  basl::NontermInfo const LinkageBlockBeginNode::info = { "LinkageBlockBeginNode", accept_89 };
}
namespace gram
{
  basl::NontermInfo const LinkageDeclBeginNode::info = { "LinkageDeclBeginNode", accept_90 };
}
namespace gram
{
  basl::NontermInfo const NavDefNode::info = { "NavDefNode", accept_91 };
}
namespace gram
{
  basl::NontermInfo const NavHeadNode::info = { "NavHeadNode", accept_92 };
}
namespace gram
{
  basl::NontermInfo const NavDirectDcl1Node::info = { "NavDirectDcl1Node", accept_93 };
}
namespace gram
{
  basl::NontermInfo const NavVisitFuncDefNode::info = { "NavVisitFuncDefNode", accept_94 };
}
namespace gram
{
  basl::NontermInfo const ReturnStmtNode::info = { "ReturnStmtNode", accept_95 };
}
namespace gram
{
  basl::NontermInfo const VdfDefNode::info = { "VdfDefNode", accept_96 };
}
namespace gram
{
  basl::NontermInfo const VdfHeadNode::info = { "VdfHeadNode", accept_97 };
}
namespace gram
{
  basl::NontermInfo const VdfFunctorDefNode::info = { "VdfFunctorDefNode", accept_98 };
}
namespace gram
{
  basl::NontermInfo const VdfShortData1DefNode::info = { "VdfShortData1DefNode", accept_99 };
}
namespace gram
{
  basl::NontermInfo const VdfShortData2DefNode::info = { "VdfShortData2DefNode", accept_100 };
}
namespace gram
{
  basl::NontermInfo const VdfDataParamListNode::info = { "VdfDataParamListNode", accept_101 };
}
namespace gram
{
  basl::NontermInfo const ObjInit4Node::info = { "ObjInit4Node", accept_102 };
}
namespace gram
{
  basl::NontermInfo const VdfBlockDataDefNode::info = { "VdfBlockDataDefNode", accept_103 };
}
namespace gram
{
  basl::NontermInfo const VdfBlockDataHead1Node::info = { "VdfBlockDataHead1Node", accept_104 };
}
namespace gram
{
  basl::NontermInfo const VdfBlockDataHead2Node::info = { "VdfBlockDataHead2Node", accept_105 };
}
namespace gram
{
  basl::NontermInfo const DirectDcl6Node::info = { "DirectDcl6Node", accept_106 };
}
#undef LZZ_INLINE
