// smtc_AccessSpec.cpp
//

#include "smtc_AccessSpec.h"
#ifndef LZZ_ENABLE_INLINE
#include "smtc_AccessSpec.inl"
#endif
#define LZZ_INLINE inline
namespace smtc
{
  AccessSpec::~ AccessSpec ()
    {}
}
#undef LZZ_INLINE
