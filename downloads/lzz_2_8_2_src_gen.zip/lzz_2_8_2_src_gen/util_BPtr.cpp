// util_BPtr.cpp
//

#include "util_BPtr.h"
#define LZZ_INLINE inline
#undef LZZ_INLINE
