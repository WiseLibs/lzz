// gram_OperTable.h
//

#ifndef LZZ_gram_OperTable_h
#define LZZ_gram_OperTable_h
// util
#include "util_Ident.h"
#define LZZ_INLINE inline
namespace gram
{
  int getOperKind (util::Ident const & name);
}
#undef LZZ_INLINE
#endif
