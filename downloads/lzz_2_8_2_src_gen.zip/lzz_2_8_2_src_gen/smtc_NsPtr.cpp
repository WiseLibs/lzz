// smtc_NsPtr.cpp
//

#include "smtc_NsPtr.h"
#include "smtc_Ns.h"
#include "util_BPtr.tpl"
#define LZZ_INLINE inline
template class util::BPtr <smtc::Ns>;
#undef LZZ_INLINE
