// util_Exception.h
//

#ifndef LZZ_util_Exception_h
#define LZZ_util_Exception_h
#define LZZ_INLINE inline
namespace util
{
  class Exception
  {
  public:
    Exception ();
    virtual ~ Exception ();
  };
}
#undef LZZ_INLINE
#endif
